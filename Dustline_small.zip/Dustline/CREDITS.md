# Credits

- **Character Jump** by SamSilcox (https://sketchfab.com/SamSilcox), CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)
  Source: https://sketchfab.com/3d-models/character-jump-fd88987f8e5541ada74e222612f5b48b
- **Parachute Simple** by sxnneh (https://sketchfab.com/Sxnneh), CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)
  Source: https://sketchfab.com/3d-models/parachute-simple-030a235d6f314a86bebc33f322c0e71c
- **Sweater Pack** by MadeByYeshe (https://sketchfab.com/MadeByYeshe), CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)
  Source: https://sketchfab.com/3d-models/sweater-pack-50fc69ff7a9a4f91ad721b44e898772d
- **T-shirt** by Sirenko (https://sketchfab.com/sirenko), CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)
  Source: https://sketchfab.com/3d-models/t-shirt-00daf5abf6d44db9a310b8264ad0e834
- **T-SHIRT 3D Model Free** by Mohammad Rajabloo (https://sketchfab.com/MohammadRajabloo), CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)
  Source: https://sketchfab.com/3d-models/t-shirt-3d-model-free-408000a9975a4c34866b42dfaca4fa75
- **T-shirt   LP** by Robin Bad (https://sketchfab.com/u-76), CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)
  Source: https://sketchfab.com/3d-models/t-shirt-lp-a8381c06f8084c5499865ac7b5e59a0b
- **FREE Survival Character (+11 textures)** by Arberry (CGTrader), CGTrader Royalty Free License (no AI)
  Source: https://www.cgtrader.com/3d-models/character/man/survival-character

- Lobby background and menu / HUD icons: created by the developer with ChatGPT (OpenAI, image generation) and used under OpenAI's Terms of Use, which give the user the rights to the output, including commercial use.
- Sounds are generated in code. Game code by the developer.
- Aircraft (passenger jet): designed with AI assistance and owned by the developer (tools/make_plane.py).
- Reload animation: original motion written for this game (ReloadAnim.kt), no third-party data.
- CHANGES NOTICE (CC BY 4.0): the models marked CC-BY-4.0 above were modified for this game: converted to the game's own file format, textures reduced in size, and scaled / posed / re-coloured. The authors do not endorse this game. Licence text: https://creativecommons.org/licenses/by/4.0/
- Guns (13 weapon models): created procedurally by the developer (tools/make_guns.py), original work.
